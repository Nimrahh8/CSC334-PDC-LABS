const grpc = require("@grpc/grpc-js");
const protoLoader = require("@grpc/proto-loader");

const packageDef = protoLoader.loadSync("audio.proto");
const grpcObject = grpc.loadPackageDefinition(packageDef);
const service = grpcObject.AudioService;

function ProcessAudio(call, callback) {
  callback(null, { processedAudio: call.request.audioData });
}

const server = new grpc.Server();
server.addService(service.service, { ProcessAudio });

server.bindAsync(
  "0.0.0.0:50052",
  grpc.ServerCredentials.createInsecure(),
  () => {
    console.log("✅ Audio Service running on 50052");
    server.start();
  }
);
