# mpi_text_analysis.py
from mpi4py import MPI
import pandas as pd
from collections import Counter
import string, time
from nltk.corpus import stopwords
import nltk
import os
import csv

nltk.download('stopwords')

def clean_text(text, stop_words, table):
    text = text.lower()
    text = text.translate(table)
    words = text.split()
    words = [w for w in words if w not in stop_words]
    return words

def process_chunk(reviews_chunk, stop_words, table):
    local_counter = Counter()
    for review in reviews_chunk:
        local_counter.update(clean_text(review, stop_words, table))
    return local_counter

comm = MPI.COMM_WORLD
rank = comm.Get_rank()
size = comm.Get_size()

stop_words = set(stopwords.words('english'))
table = str.maketrans('', '', string.punctuation)

# Optional: rank 0 gets 50% of data, rest equally share remaining
imbalance = True

if rank == 0:
    # Master reads the dataset
    df = pd.read_csv("IMDB Dataset.csv")
    reviews = df['review'].astype(str).tolist()
    total_lines = len(reviews)
    
    # Split data
    if imbalance:
        part0_size = total_lines // 2
        remaining = reviews[part0_size:]
        chunks = [reviews[:part0_size]]  # rank 0
        # Split remaining among other ranks
        per_rank = len(remaining) // (size - 1)
        for i in range(1, size-1):
            chunks.append(remaining[(i-1)*per_rank : i*per_rank])
        chunks.append(remaining[(size-2)*per_rank:])  # last rank
    else:
        per_rank = total_lines // size
        chunks = [reviews[i*per_rank:(i+1)*per_rank] for i in range(size-1)]
        chunks.append(reviews[(size-1)*per_rank:])

    # Send chunks to worker ranks
    for i in range(1, size):
        comm.send(chunks[i], dest=i, tag=11)

    # Master processes its own chunk
    start_time = time.perf_counter()
    local_counter = process_chunk(chunks[0], stop_words, table)
    end_time = time.perf_counter()
    print(f"Rank 0 processed {len(chunks[0])} lines in {end_time - start_time:.2f}s")

    # Receive results from workers
    total_counter = local_counter
    worker_times = [end_time - start_time]
    for i in range(1, size):
        worker_counter, worker_len, worker_time = comm.recv(source=i, tag=22)
        total_counter.update(worker_counter)
        print(f"Rank {i} processed {worker_len} lines in {worker_time:.2f}s")
        worker_times.append(worker_time)

    total_time = max(worker_times)
    print(f"Total distributed time: {total_time:.2f}s")

    # Optional: speedup over sequential
    sequential_time = 58.0  
    speedup = sequential_time / total_time
    print(f"Speedup over sequential: {speedup:.2f}x")

    # ---------- Save output ----------
    output_folder = "mpi_output"
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    top_20 = total_counter.most_common(20)
    output_file = os.path.join(output_folder, "mpi_output.csv")
    with open(output_file, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["word", "count"])
        writer.writerows(top_20)

    print(f"MPI output saved in '{output_file}'")

else:
    # Worker ranks receive their chunk
    chunk = comm.recv(source=0, tag=11)
    start_time = time.perf_counter()
    local_counter = process_chunk(chunk, stop_words, table)
    end_time = time.perf_counter()
    worker_time = end_time - start_time
    # Send local counter and processing info back to master
    comm.send((local_counter, len(chunk), worker_time), dest=0, tag=22)
