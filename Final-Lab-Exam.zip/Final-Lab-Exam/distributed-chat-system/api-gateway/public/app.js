const API_URL = "http://localhost:3000"; // Make sure port matches your API Gateway

// Set Language
document.getElementById("setLanguageBtn").onclick = async () => {
  const userId = document.getElementById("userId").value;
  const language = document.getElementById("language").value;
  try {
    const res = await fetch(`${API_URL}/api/user/language`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId, language }),
    });
    const data = await res.json();
    showResult("langResult", data.status, true);
  } catch (err) {
    showResult("langResult", err.message, false);
  }
};

// Send Text
document.getElementById("sendTextBtn").onclick = async () => {
  const to = document.getElementById("toUser").value;
  const message = document.getElementById("message").value;
  try {
    const res = await fetch(`${API_URL}/api/chat/text`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ to, message }),
    });
    const data = await res.json();
    showResult("textResult", data.translatedText, true);
  } catch (err) {
    showResult("textResult", err.message, false);
  }
};

// Send Audio
document.getElementById("sendAudioBtn").onclick = async () => {
  const userId = document.getElementById("audioUser").value;
  const file = document.getElementById("audioFile").files[0];
  if (!file) return alert("Select an audio file first");
  
  const reader = new FileReader();
  reader.onload = async () => {
    const base64Audio = reader.result.split(",")[1];
    try {
      const res = await fetch(`${API_URL}/api/chat/audio`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ to: userId, audio: base64Audio }),
      });
      const data = await res.json();
      const audioPlayer = document.getElementById("audioPlayer");
      audioPlayer.src = "data:audio/wav;base64," + data.audio;
      audioPlayer.style.display = "block";
      showResult("audioResult", "Audio processed successfully", true);
    } catch (err) {
      showResult("audioResult", err.message, false);
    }
  };
  reader.readAsDataURL(file);
};

// Helper function to show results
function showResult(id, message, success = true) {
  const el = document.getElementById(id);
  el.textContent = message;
  el.className = success ? "result success" : "result error";
}
