const express = require("express");
const bodyParser = require("body-parser");
const grpc = require("@grpc/grpc-js");
const protoLoader = require("@grpc/proto-loader");
const path = require("path");

const app = express();
app.use(bodyParser.json());

// Serve frontend
app.use(express.static(path.join(__dirname, "public")));

// In-memory user language store
const users = {};

// --- Translation client ---
const tDef = protoLoader.loadSync(
  path.join(__dirname, "../translation-service/translation.proto")
);
const tPkg = grpc.loadPackageDefinition(tDef);
const translationClient = new tPkg.TranslationService(
  "localhost:50051",
  grpc.credentials.createInsecure()
);

// --- Audio client ---
const aDef = protoLoader.loadSync(
  path.join(__dirname, "../audio-service/audio.proto")
);
const aPkg = grpc.loadPackageDefinition(aDef);
const audioClient = new aPkg.AudioService(
  "localhost:50052",
  grpc.credentials.createInsecure()
);

// --- Set user language ---
app.post("/api/user/language", (req, res) => {
  const { userId, language } = req.body;
  users[userId] = language;
  res.json({ status: "Language set", userId, language });
});

// --- Send text message ---
app.post("/api/chat/text", (req, res) => {
  const { to, message } = req.body;
  const lang = users[to] || "en"; // default to English

  console.time("REST_TEXT");
  translationClient.TranslateText(
    { text: message, targetLanguage: lang },
    (err, response) => {
      console.timeEnd("REST_TEXT");
      if (err) return res.status(500).json({ error: err.message });
      res.json(response);
    }
  );
});

// --- Send audio message ---
app.post("/api/chat/audio", (req, res) => {
  const { audio } = req.body;
  const audioBuffer = Buffer.from(audio, "base64");

  console.time("REST_AUDIO");
  audioClient.ProcessAudio({ audioData: audioBuffer }, (err, response) => {
    console.timeEnd("REST_AUDIO");
    if (err) return res.status(500).json({ error: err.message });

    res.json({
      audio: response.processedAudio.toString("base64"),
    });
  });
});

// --- Start server ---
app.listen(3000, () => {
  console.log("✅ API Gateway running on port 3000");
  console.log("👉 Open http://localhost:3000 in your browser");
});
