# hybrid_text_pipeline.py
from mpi4py import MPI
import pandas as pd
from collections import Counter
import string, time, os
from nltk.corpus import stopwords
import nltk
from multiprocessing import Pool

nltk.download('stopwords')

def clean_text(text, stop_words, table):
    text = text.lower()
    text = text.translate(table)
    words = text.split()
    words = [w for w in words if w not in stop_words]
    return words

def process_chunk(reviews_chunk):
    local_counter = Counter()
    for review in reviews_chunk:
        local_counter.update(clean_text(review, stop_words, table))
    return local_counter

def parallel_worker(chunk, n_processes):
    # Split chunk for local multiprocessing
    size = len(chunk)
    per_proc = size // n_processes
    chunks = [chunk[i*per_proc:(i+1)*per_proc] for i in range(n_processes-1)]
    chunks.append(chunk[(n_processes-1)*per_proc:])
    with Pool(processes=n_processes) as pool:
        results = pool.map(process_chunk, chunks)
    total_counter = Counter()
    for r in results:
        total_counter.update(r)
    return total_counter

# MPI setup
comm = MPI.COMM_WORLD
rank = comm.Get_rank()
size = comm.Get_size()

stop_words = set(stopwords.words('english'))
table = str.maketrans('', '', string.punctuation)

# Parameters
local_processes = 2  # number of multiprocessing workers per MPI node

if rank == 0:
    # Master reads dataset
    df = pd.read_csv("IMDB Dataset.csv")
    reviews = df['review'].astype(str).tolist()
    sentiments = df['sentiment'].tolist()
    total_lines = len(reviews)

    # Split dataset among MPI ranks
    per_rank = total_lines // size
    chunks = []
    sentiment_chunks = []
    for i in range(size-1):
        chunks.append(reviews[i*per_rank:(i+1)*per_rank])
        sentiment_chunks.append(sentiments[i*per_rank:(i+1)*per_rank])
    # Last rank gets remainder
    chunks.append(reviews[(size-1)*per_rank:])
    sentiment_chunks.append(sentiments[(size-1)*per_rank:])
    
    start_total = time.perf_counter()

    # Send chunks to other ranks
    for i in range(1, size):
        comm.send((chunks[i], sentiment_chunks[i]), dest=i, tag=11)

    # Master processes its own chunk
    # Example: rank 0 counts only positive reviews
    pos_chunk = [r for r, s in zip(chunks[0], sentiment_chunks[0]) if s.lower()=='positive']
    start_time = time.perf_counter()
    local_counter = parallel_worker(pos_chunk, local_processes)
    end_time = time.perf_counter()
    print(f"Node 0 (positive): processed {len(pos_chunk)} reviews in {end_time - start_time:.2f}s")

    # Receive from workers
    total_counter = local_counter
    comm_times = []
    for i in range(1, size):
        worker_counter, worker_len, worker_time = comm.recv(source=i, tag=22)
        total_counter.update(worker_counter)
        print(f"Node {i} ({'positive' if i%2==0 else 'negative'}): processed {worker_len} reviews in {worker_time:.2f}s")
        comm_times.append(worker_time)

    end_total = time.perf_counter()
    communication_overhead = (end_total - start_total) - max([end_time - start_time]+comm_times)
    print(f"Communication overhead: {communication_overhead:.2f}s")
    print(f"Hybrid total time: {end_total - start_total:.2f}s")

    # Example sequential time for speedup calculation
    sequential_time = 58.0
    speedup = sequential_time / (end_total - start_total)
    print(f"Hybrid speedup: {speedup:.2f}x vs Sequential")

    # Top 20 words
    top_20 = total_counter.most_common(20)
    os.makedirs('hybrid_output', exist_ok=True)
    import csv
    with open('hybrid_output/top_20_words.csv', 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['word','count'])
        writer.writerows(top_20)

else:
    # Worker ranks
    chunk, sentiments = comm.recv(source=0, tag=11)
    # Apply sentiment filter: even ranks positive, odd ranks negative
    if rank % 2 == 0:
        filtered_chunk = [r for r, s in zip(chunk, sentiments) if s.lower()=='positive']
    else:
        filtered_chunk = [r for r, s in zip(chunk, sentiments) if s.lower()=='negative']

    start_time = time.perf_counter()
    local_counter = parallel_worker(filtered_chunk, local_processes)
    end_time = time.perf_counter()
    worker_time = end_time - start_time
    comm.send((local_counter, len(filtered_chunk), worker_time), dest=0, tag=22)
