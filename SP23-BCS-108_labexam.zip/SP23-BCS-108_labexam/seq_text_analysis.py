import pandas as pd
from collections import Counter
import string, time, os
from nltk.corpus import stopwords
import nltk

nltk.download('stopwords')

start_time = time.perf_counter()

# Load first 20k rows
df = pd.read_csv("IMDB Dataset.csv").head(20000)

# Use the correct column name
reviews = df['review'].astype(str).tolist()
stop_words = set(stopwords.words('english'))
table = str.maketrans('', '', string.punctuation)

def clean_text(text):
    text = text.lower()
    text = text.translate(table)
    words = text.split()
    words = [w for w in words if w not in stop_words]
    return words

counter = Counter()
for review in reviews:
    counter.update(clean_text(review))

top_20 = counter.most_common(20)

# Create output folder if it doesn't exist
os.makedirs('sample_output', exist_ok=True)

# Write top 20 words to CSV
import csv
with open('sample_output/seq_output.csv', 'w', newline='') as f:
    writer = csv.writer(f)
    writer.writerow(['word','count'])
    writer.writerows(top_20)

end_time = time.perf_counter()
print(f"Processed {len(reviews)} reviews in {end_time - start_time:.2f} seconds.")
print("Top words:", top_20)
