# parallel_text_analysis.py
import pandas as pd
from collections import Counter
import string, time, os
from nltk.corpus import stopwords
import nltk
from multiprocessing import Pool

# Download stopwords
nltk.download('stopwords')

# Function to clean and tokenize text
def clean_text(text, stop_words, table):
    text = text.lower()
    text = text.translate(table)
    words = text.split()
    words = [w for w in words if w not in stop_words]
    return words

# Function for worker to process a chunk of reviews
def process_chunk(reviews_chunk):
    local_counter = Counter()
    for review in reviews_chunk:
        local_counter.update(clean_text(review, stop_words, table))
    return local_counter

if __name__ == "__main__":
    start_total = time.perf_counter()

    # Create output folder
    os.makedirs('parallel_output', exist_ok=True)

    # Load dataset
    df = pd.read_csv("IMDB Dataset.csv").head(20000)
    reviews = df['review'].astype(str).tolist()

    # Prepare stopwords and punctuation table
    stop_words = set(stopwords.words('english'))
    table = str.maketrans('', '', string.punctuation)

    # Worker settings
    worker_counts = [1, 2, 4, 8]
    base_time = None

    # Store performance results
    performance = []

    for workers in worker_counts:
        start_time = time.perf_counter()

        # Split reviews into roughly equal chunks per worker
        chunk_size = len(reviews) // workers
        chunks = [reviews[i*chunk_size : (i+1)*chunk_size] for i in range(workers-1)]
        chunks.append(reviews[(workers-1)*chunk_size:])  # last chunk includes remainder

        # Parallel processing
        with Pool(processes=workers) as pool:
            results = pool.map(process_chunk, chunks)

        # Merge all counters
        total_counter = Counter()
        for r in results:
            total_counter.update(r)

        end_time = time.perf_counter()
        elapsed = end_time - start_time

        if base_time is None:
            base_time = elapsed  # time for 1 worker

        speedup = base_time / elapsed
        efficiency = (speedup / workers) * 100

        performance.append([workers, round(elapsed, 2), f"{speedup:.2f}x", round(efficiency, 1)])

        # Save top 20 words for this run
        top_20 = total_counter.most_common(20)
        with open(f'parallel_output/top_20_words_{workers}_workers.csv', 'w', newline='') as f:
            import csv
            writer = csv.writer(f)
            writer.writerow(['word','count'])
            writer.writerows(top_20)

        print(f"Workers: {workers} | Time: {elapsed:.2f}s | Speedup: {speedup:.2f}x | Efficiency: {efficiency:.1f}%")

    # Save performance summary
    with open('parallel_output/performance_summary.csv', 'w', newline='') as f:
        import csv
        writer = csv.writer(f)
        writer.writerow(['Workers', 'Time (s)', 'Speedup', 'Efficiency (%)'])
        writer.writerows(performance)

    end_total = time.perf_counter()
    print(f"\nTotal processing time: {end_total - start_total:.2f}s")
