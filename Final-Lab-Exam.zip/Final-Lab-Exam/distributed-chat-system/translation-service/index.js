const grpc = require("@grpc/grpc-js");
const protoLoader = require("@grpc/proto-loader");

const packageDef = protoLoader.loadSync("translation.proto");
const grpcObject = grpc.loadPackageDefinition(packageDef);
const service = grpcObject.TranslationService;

const translations = {
  "hello_fr": "bonjour",
  "hello_es": "hola",
};

function TranslateText(call, callback) {
  const key = `${call.request.text.toLowerCase()}_${call.request.targetLanguage}`;
  callback(null, {
    translatedText: translations[key] || call.request.text,
  });
}

const server = new grpc.Server();
server.addService(service.service, { TranslateText });

server.bindAsync(
  "0.0.0.0:50051",
  grpc.ServerCredentials.createInsecure(),
  () => {
    console.log("✅ Translation Service running on 50051");
    server.start();
  }
);
